class OneTime extends Appointment
{
 
    public OneTime(int day, int month, int year, String des)
    {
        super(day, month, year, des);
    }
   
}    
